# Anupam Roy — Portfolio

All content lives in `src/data/resume.js`. Edit that file and the site updates.

- Replace `public/profile.png` with your photo.
- Add your CV as `public/resume.pdf` and set `resumeUrl: asset('resume.pdf')` in `resume.js`.
- Add LinkedIn / ResearchGate / GitHub links in `profile.socials`.

Run locally: `npm install` then `npm run dev`. Deploys to GitHub Pages via `.github/workflows/deploy.yml`.
