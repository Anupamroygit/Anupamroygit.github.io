import { asset } from '../lib/asset.js';

export const profile = {
  name: 'Anupam Roy',
  /** Cycled one at a time under the name by <RoleRotator />. */
  roles: [
    'Avionics Engineer',
    'Antenna & RF Researcher',
    'Radar & 6G ISAC Researcher',
    'Wireless Communication Researcher',
  ],
  location: 'Khulna, Bangladesh',
  /* TODO: replace public/profile.png with your own photo (same file name). */
  photo: asset('profile.png'),
  /* TODO: put your CV in public/resume.pdf and set resumeUrl to asset('resume.pdf').
     While this is null, the Résumé buttons are hidden. */
  resumeUrl: null,
  resumeFileName: 'Anupam-Roy-Resume.pdf',
  email: 'anupamroy0103@gmail.com',
  website: null,
  /**
   * TODO: add your profile links here, then they appear as icons under the card.
   * Example entries (icons available: github, linkedin, scholar, orcid,
   * researchgate, whatsapp, mail):
   *
   * { name: 'LinkedIn', icon: 'linkedin', url: 'https://www.linkedin.com/in/YOUR-ID/', color: '#0a66c2' },
   * { name: 'ResearchGate', icon: 'researchgate', url: 'https://www.researchgate.net/profile/YOUR-ID', color: '#00857a' },
   * { name: 'GitHub', icon: 'github', url: 'https://github.com/YOUR-ID', color: '#24292f' },
   */
  socials: [
    { name: 'Email', icon: 'mail', url: 'mailto:anupamroy0103@gmail.com', color: '#b4472b' },
  ],
};

export const researchInterests = [
  {
    term: 'Antenna Design',
    detail:
      'UWB and multiband microstrip patch antennas, MIMO isolation techniques and reconfigurable antennas.',
  },
  {
    term: 'Radar Signal Processing',
    detail: 'Pulse radar modelling and parameter analysis in MATLAB and Simulink.',
  },
  {
    term: 'Integrated Sensing and Communication (6G ISAC)',
    detail:
      'Radar-native foundation models and agentic learning for scene understanding in high-mobility 6G networks.',
  },
  {
    term: 'Next-Generation Waveforms',
    detail: 'OTFS-based waveform design and implementation for future wireless communication.',
  },
  {
    term: 'Adaptive Signal Processing',
    detail: 'Adaptive filtering for signal enhancement in modern communication systems.',
  },
];

/* `short` is what the phone navigation shows; `label` titles the card. */
export const sections = [
  { id: 'about', label: 'About', short: 'About', accent: '#1e3a5f' },
  { id: 'education', label: 'Education & Skills', short: 'Education', accent: '#2f5d62' },
  { id: 'experience', label: 'Experience & Projects', short: 'Experiences', accent: '#8a5a3b' },
  { id: 'publications', label: 'Publications', short: 'Publications', accent: '#7a3b4a' },
  { id: 'honors', label: 'Scholarships & Awards', short: 'Awards', accent: '#7d6033' },
  { id: 'leadership', label: 'Leadership & Service', short: 'Leadership', accent: '#5b4b7a' },
  /* References section is switched off: no referees listed yet. To bring it back,
     add { id: 'references', label: 'References', short: 'References', accent: '#6b5b4e' }
     here and fill the `references` list at the bottom of this file. */
];

/** Jobs and posts. */
export const jobs = [
  {
    date: '2019 to 2025',
    roles: [],
    org: 'Teaching Assistant',
    orgUrl: null,
    location: null,
    supervisor: null,
    hours: null,
    description:
      'Assisted SSC and HSC students in Mathematics and Science through tutorials and guided problem-solving in algebra, calculus, physics and other core scientific concepts.',
    tags: ['Mathematics', 'Physics', 'Tutoring'],
    journey: [],
    gallery: [],
  },
];

/** Degree research and research posts. */
export const research = [
  {
    date: 'Jan 2025 to Dec 2025',
    roles: [{ title: 'Undergraduate Thesis', period: 'Jan 2025 to Dec 2025' }],
    org: 'UWB Microstrip Patch Antenna and MIMO',
    orgUrl: null,
    location: 'Aviation and Aerospace University, Bangladesh',
    supervisor: null,
    hours: null,
    description:
      'Designed and fabricated a compact 4-element UWB microstrip MIMO antenna covering 3.1 to 10.25 GHz, using spike-shaped radiators and defected ground structures (DGS) to improve isolation and reduce mutual coupling. The design achieved 24 dB isolation, an ECC of 4.5 × 10⁻³, a maximum gain of 1.85 dBi and 68% radiation efficiency, with a minimum measured S11 of −55.73 dB.',
    tags: ['UWB Antenna', 'MIMO', 'DGS', 'CST Studio Suite'],
    journey: [],
    gallery: [],
  },
  {
    date: 'Jan 2022 to Dec 2025',
    roles: [{ title: 'Research Assistant', period: 'Jan 2022 to Dec 2025' }],
    org: 'Rocket Project',
    orgUrl: null,
    location: 'Aviation and Aerospace University, Bangladesh',
    supervisor: null,
    hours: null,
    description:
      'Contributed to the design and testing of the Electrical Power System (EPS) for rocket systems, including power management, system analysis, software integration and prototype testing.',
    tags: ['Electrical Power System', 'Power Management', 'Prototype Testing'],
    journey: [],
    gallery: [],
  },
];

/** Competition team roles. Empty for now, so the heading is hidden. */
export const teamExperience = [];

export const internships = [
  {
    org: 'Civil Aviation Authority of Bangladesh (CAAB), Radar Unit Visit',
    detail:
      'Exposure to radar surveillance systems and ATC operational monitoring that support flight safety and regulatory compliance',
    duration: 'Nov 2025',
  },
  {
    org: 'Bangladesh Air Force, MROU 208 & MROU 216',
    detail:
      'Industrial trainee. Aircraft maintenance, inspection and repair, avionics troubleshooting, component servicing, maintenance documentation and safety procedures',
    duration: 'Jun–Jul 2024',
  },
];

export const internshipsIntro =
  'Industrial training and visits to aviation maintenance and air-traffic radar facilities in Bangladesh.';

export const projects = [
  {
    art: 'radar',
    title: 'Simulation and Parameter Analysis of a Monostatic Pulse Radar in MATLAB/Simulink',
    url: null,
    description:
      'Developed a radar-assisted distributed predictive control framework enabling cooperative autonomous vehicles to make real-time, safe and adaptive decisions in dynamic traffic environments.',
    tags: ['MATLAB', 'Simulink', 'Pulse Radar'],
    meta: 'May 2026 to Jun 2026',
    photo: null,
    journey: [],
    gallery: [],
  },
  {
    art: 'altimeter',
    title: 'Real-Time Monitoring of Sensor Data Using IoT and Blynk Server',
    url: null,
    description:
      'Developed an IoT-based real-time environmental monitoring system using a Raspberry Pi and an SHT20 temperature–humidity sensor, with remote monitoring through the Blynk server.',
    tags: ['Raspberry Pi', 'IoT', 'SHT20', 'Blynk'],
    meta: 'Jul 2024 to Dec 2024',
    photo: null,
    journey: [],
    gallery: [],
  },
];

export const publications = [
  {
    title:
      'Closed-Loop Sensor-Informed Agentic Foundation Learning for Adaptive Radar-Native Scene Understanding in High-Mobility 6G ISAC Networks',
    venue: '14th International Conference on Electrical and Computer Engineering (ICECE 2026)',
    place: null,
    year: '2026',
    status: 'Under review · 1st Author',
    doi: null,
    url: null,
    abstract: '',
    presentation: null,
  },
  {
    title: 'Radar-Native Foundation Model for Semantic Understanding of Synthetic Aperture Radar Imagery in 6G ISAC',
    venue: '14th International Conference on Electrical and Computer Engineering (ICECE 2026)',
    place: null,
    year: '2026',
    status: 'Under review · 1st Author',
    doi: null,
    url: null,
    abstract: '',
    presentation: null,
  },
  {
    title: 'Adaptive Filtering Techniques for Signal Enhancement in Modern Communication Systems',
    venue: '11th IEEE Asia-Pacific Conference on Computer Science and Data Engineering',
    place: null,
    year: '2026',
    status: 'Accepted · Co-Author',
    doi: null,
    url: null,
    abstract: '',
    presentation: null,
  },
  {
    title:
      'Design and Implementation of OTFS-Based Waveforms for Next Generation Wireless Communication Using MATLAB',
    venue: '2026 IEEE International Conference on Optics, Machine Learning and Emerging Technology (OMLET)',
    place: null,
    year: '2026',
    status: 'Accepted · 1st Author',
    doi: null,
    url: null,
    abstract: '',
    presentation: null,
  },
  {
    title: 'Optimized Multiband Microstrip Patch Antenna with Circular DGS for Enhanced 6 GHz Performance',
    venue:
      '16th International IEEE Conference on Computing, Communication and Networking Technologies (ICCCNT)',
    place: null,
    year: '2025',
    status: 'Presented · Co-author · Publication in process',
    doi: null,
    url: null,
    abstract: '',
    presentation: null,
  },
  {
    title: 'Reconfigurable Dual-Ring Patch Antenna with Varactor-Diode Based Frequency Tuning',
    venue:
      'IEEE 7th International Conference on Electrical Information and Communication Technology (EICT)',
    place: null,
    year: '',
    status: '1st Author & Presenter',
    doi: null,
    url: null,
    abstract: '',
    presentation: null,
  },
];

/** Empty lists hide their headings on the Publications card. */
export const posters = [];
export const grants = [];

export const education = [
  {
    date: '2022 to March 2026',
    degree: 'BSc in Avionics Engineering',
    school: 'Aviation and Aerospace University, Bangladesh (AAUB)',
    schoolUrl: 'https://aaub.edu.bd',
    location: 'Bangladesh',
    result: 'CGPA 3.52 / 4.00',
    detail:
      'Thesis: UWB Microstrip Patch Antenna and MIMO. A Certificate of Medium of Instruction (English) is available on request.',
    coursework: null,
  },
];

export const awards = [
  {
    year: '2025',
    title: 'AAUB Special Scholarship',
    detail: 'Awarded for achieving a GPA of 3.85 in the 7th semester',
  },
  {
    year: '2023',
    title: 'AAUB Merit Scholarship',
    detail: 'Awarded for achieving a GPA of 3.64 in the 2nd semester',
  },
  {
    year: '2022',
    title: 'University Admission Test Merit Position: 42nd',
    detail: 'AAUB. BDT 10,000 merit scholarship for outstanding performance in the admission test',
  },
  {
    year: '2022',
    title: 'Rocketry Innovation Challenge',
    detail:
      'Top 10 entries for an outstanding research idea, national competition organised by a2i (Aspire to Innovate), ICT Division of Bangladesh',
  },
];

export const leadership = [
  {
    period: '2026 to Present',
    role: 'Manuscript Reviewer',
    org: 'IEEE Geoscience and Remote Sensing Society (GRSS)',
  },
  {
    period: '2022 to 2025',
    role: 'Outreach Secretary',
    org: 'AAUB Drone Club. Led campus-wide outreach, event planning, budgeting, sponsorship coordination and team management',
  },
];

/** Not shown at the moment, see the note in `sections`. */
export const references = [];

export const skills = [
  {
    category: 'Programming',
    items: [
      { name: 'Python', note: 'Intermediate' },
      { name: 'C' },
      { name: 'C++', note: 'Intermediate' },
    ],
  },
  {
    category: 'RF, Simulation & Modeling',
    items: [
      { name: 'CST Studio Suite', hi: true, note: 'Intermediate' },
      { name: 'MATLAB', hi: true, note: 'Intermediate' },
      { name: 'Simulink', hi: true, note: 'Intermediate' },
      { name: 'PSpice', note: 'Proficient' },
    ],
  },
  {
    category: 'Embedded Systems & IoT',
    items: [{ name: 'Arduino IDE' }, { name: 'Raspberry Pi', note: 'Intermediate' }],
  },
  {
    category: 'Technical Tools',
    items: [
      { name: 'LaTeX', hi: true, note: 'Proficient' },
      { name: 'Microsoft Office', note: 'Proficient' },
      { name: 'Google Workspace', note: 'Proficient' },
      { name: 'Canva', note: 'Proficient' },
    ],
  },
  {
    category: 'Languages',
    items: [
      { name: 'Bangla', note: 'Native' },
      { name: 'English', note: 'Proficient' },
      { name: 'Hindi', note: 'Conversational' },
    ],
  },
];
