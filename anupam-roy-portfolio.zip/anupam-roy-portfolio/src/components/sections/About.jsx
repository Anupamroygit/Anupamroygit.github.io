import { useState } from 'react';
import { researchInterests } from '../../data/resume';
import { InlineLink, Subheading, MoreButton, MarkerList } from '../ui';
import SubPage from '../SubPage';

/** The long version, kept off the front of the card so Research sits high. */
function FullStory() {
  return (
    <div className="space-y-4 text-justify text-base sm:text-lg">
      <p>
        I am an Avionics Engineering graduate from the Aviation and Aerospace University,
        Bangladesh, based in Khulna. My work sits where antenna design, radar and wireless
        communication meet, and I like to see an idea through from simulation to a fabricated and
        measured prototype.
      </p>

      <p>
        My undergraduate thesis was a compact 4-element UWB microstrip MIMO antenna covering 3.1
        to 10.25 GHz. I designed it in simulation, fabricated it and measured it, reaching 24 dB
        of isolation and a minimum measured S11 of −55.73 dB. Alongside it I have worked on
        multiband and reconfigurable patch antennas, which have led to conference papers at
        ICCCNT and EICT.
      </p>

      <p>
        More recently my interest has moved toward radar and 6G integrated sensing and
        communication (ISAC). I have written papers on radar-native foundation models and agentic
        learning for ISAC networks, on OTFS waveforms for next-generation wireless systems and on
        adaptive filtering, and I have modelled a monostatic pulse radar in MATLAB and Simulink.
      </p>

      <p>
        Earlier I spent several years as a research assistant on the university's rocket project,
        working on the electrical power system, and I completed industrial training with the
        Bangladesh Air Force and a visit to the radar unit of the Civil Aviation Authority of
        Bangladesh. These gave me a practical view of how aviation systems are built, maintained
        and kept safe.
      </p>

      <p>
        Outside research I served as Outreach Secretary of the AAUB Drone Club, review manuscripts
        for the IEEE Geoscience and Remote Sensing Society and have tutored school students in
        mathematics and science.
      </p>
    </div>
  );
}

export default function About() {
  const [showStory, setShowStory] = useState(false);

  if (showStory) {
    return (
      <SubPage onBack={() => setShowStory(false)}>
        <FullStory />
      </SubPage>
    );
  }

  return (
    <div className="text-ink-soft">
      <p className="text-justify text-base sm:text-lg">
        I am an Avionics Engineering graduate of{' '}
        <InlineLink href="https://aaub.edu.bd">
          Aviation and Aerospace University, Bangladesh
        </InlineLink>{' '}
        with a CGPA of 3.52 / 4.00. My work spans{' '}
        <span className="font-medium text-ink">antenna design</span>,{' '}
        <span className="font-medium text-ink">radar signal processing</span> and{' '}
        <span className="font-medium text-ink">6G integrated sensing and communication (ISAC)</span>
        . I have authored and co-authored several IEEE conference papers, designed and fabricated a
        UWB MIMO antenna for my thesis and contributed to the electrical power system of a
        university rocket project.{' '}
        <MoreButton onClick={() => setShowStory(true)}>Read More</MoreButton>
      </p>

      <div className="mt-7">
        <Subheading>Research Focus</Subheading>

        <p className="text-justify text-base sm:text-lg">
          My research focuses on compact and reconfigurable antennas for modern wireless systems,
          and on radar-native learning methods for 6G ISAC networks, including scene
          understanding from synthetic aperture radar imagery. I am also interested in next
          generation waveforms such as OTFS and in adaptive signal processing.
        </p>
      </div>

      <div className="mt-7">
        <Subheading>Research Interest</Subheading>

        <MarkerList items={researchInterests} />
      </div>
    </div>
  );
}
